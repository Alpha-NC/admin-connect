// ============================================
// AdminConnect — Simulation Engine v3
// ============================================
'use strict';
const AC={alerts:4,timer:{seconds:0,running:false,interval:null,taskLabel:'Mission accompagnement RH'},notifHistory:[],aiChat:{open:false,messages:[]},activityLog:[],onboarding:{done:localStorage.getItem('ac_ob')==='1'}};
function pad(n){return String(n).padStart(2,'0')}
function fmtTime(s){return`${pad(Math.floor(s/3600))}:${pad(Math.floor((s%3600)/60))}:${pad(s%60)}`}
function g(id){return document.getElementById(id)}

// TOAST
function showToast(msg,type='success',dur=3500){
  let w=g('toastContainer');
  if(!w){w=document.createElement('div');w.id='toastContainer';w.style.cssText='position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none';document.body.appendChild(w)}
  const C={success:'#22863A',warning:'#B95000',error:'#D92D20',info:'#2B7DC4'};
  const I={success:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><polyline points="20 6 9 17 4 12"/></svg>',warning:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',error:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',info:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'};
  const t=document.createElement('div');
  t.style.cssText=`display:flex;align-items:flex-start;gap:10px;padding:12px 16px;background:#fff;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,0.14);border-left:3px solid ${C[type]||C.info};font-family:'DM Sans',sans-serif;font-size:13.5px;color:#1E1D1B;min-width:260px;max-width:360px;opacity:0;transform:translateX(20px);transition:all .28s cubic-bezier(.22,1,.36,1);pointer-events:all;line-height:1.45`;
  t.innerHTML=`<span style="color:${C[type]||C.info};flex-shrink:0;margin-top:1px">${I[type]||I.info}</span><span style="flex:1">${msg}</span><button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:#C5C3BC;font-size:14px;padding:0;flex-shrink:0;line-height:1">✕</button>`;
  w.appendChild(t);
  requestAnimationFrame(()=>{t.style.opacity='1';t.style.transform='translateX(0)'});
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(16px)';setTimeout(()=>t.remove(),300)},dur);
  AC.activityLog.unshift({time:new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),msg:msg.replace(/<[^>]+>/g,''),type});
  refreshActivityFeed();
}

// MODAL
function openModal(id){const m=g(id);if(!m)return;m.style.display='flex';requestAnimationFrame(()=>m.classList.add('modal-open'));document.body.style.overflow='hidden';setTimeout(()=>m.querySelector('input,textarea,select')?.focus(),160)}
function closeModal(id){const m=g(id);if(!m)return;m.classList.remove('modal-open');setTimeout(()=>{m.style.display='none'},250);document.body.style.overflow=''}
document.addEventListener('click',e=>{if(e.target.classList.contains('modal-backdrop'))closeModal(e.target.id)});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')document.querySelectorAll('.modal-backdrop.modal-open').forEach(m=>closeModal(m.id));
  if(e.key==='n'&&!e.target.closest('input,textarea,select'))openModal('newClientModal');
  if((e.metaKey||e.ctrlKey)&&e.key==='k'){e.preventDefault();openSearch()}
  if((e.metaKey||e.ctrlKey)&&e.key==='/')  {e.preventDefault();toggleAIChat()}
});

// LIVE EVENTS
const LIVE=[
  {d:9000,  fn:()=>pushNotif('📬 Florent Sauvage a ouvert votre email de relance','info')},
  {d:22000, fn:()=>pushNotif('✅ Marie Castel a payé la facture #2026-038 — 7 800 €','success')},
  {d:38000, fn:()=>pushNotif('⚠️ Rappel automatique J+8 — Devis Florent Sauvage non répondu','warning')},
  {d:55000, fn:()=>{pushNotif('🎉 Nouveau client ajouté automatiquement — BatiVox SAS','success');addLiveRow()}},
  {d:75000, fn:()=>pushNotif('💳 Virement reçu : Thomas Mercier — 3 200 €','success')},
  {d:95000, fn:()=>pushNotif('🤖 Score IA mis à jour — Baptiste Morel : 9.4/10 (critique)','warning')},
  {d:115000,fn:()=>pushNotif('📄 PV Yousign — Signature en attente depuis 24h','info')},
  {d:135000,fn:()=>{pushNotif('🎊 Taux de signature ce mois : 91% — nouveau record !','success');updateKPI()}},
];
function startLiveEvents(){LIVE.forEach(ev=>setTimeout(ev.fn,ev.d))}

function pushNotif(message,type){
  showToast(message,type,5500);
  AC.alerts++;updateBadge();
  AC.notifHistory.unshift({message,type,time:new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})});
  refreshNotifPanel();
}

function addLiveRow(){
  const tbody=document.querySelector('.client-table tbody');if(!tbody)return;
  const tr=document.createElement('tr');
  tr.style.cssText='cursor:pointer;animation:fadeUp .5s ease;background:rgba(232,93,58,0.04)';
  tr.onclick=()=>window.location='pages/client.html';
  tr.innerHTML=`<td><div class="client-cell"><div class="client-avatar" style="background:#F0F5FF;color:#3B5BDB">BV</div><div><div class="client-name">BatiVox SAS <span style="font-size:10px;background:var(--coral);color:white;padding:1px 6px;border-radius:10px;margin-left:5px">Nouveau</span></div><div class="client-meta">PME · BTP · 12 salariés</div></div></div></td><td><span class="badge badge-info" onclick="event.stopPropagation();cycleStatus(this)" style="cursor:pointer">En cours</span></td><td class="amount">—</td><td class="date-cell"><span style="color:var(--coral);font-weight:500">À l'instant</span></td><td><div class="score-cell"><div class="score-bar"><div class="score-fill score-ok" style="width:8%"></div></div><span class="score-num ok">0.8</span></div></td><td><span class="relance-badge relance-none">Aucune</span></td><td class="actions-cell" onclick="event.stopPropagation()"><button class="icon-btn" onclick="showToast('Email envoyé à BatiVox ✓','success')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></button><button class="icon-btn" onclick="window.location='pages/client.html'">→</button></td>`;
  tbody.prepend(tr);
}

function updateKPI(){
  const kpiCards=document.querySelectorAll('.kpi-card');
  if(kpiCards[3]){const v=kpiCards[3].querySelector('.kpi-value');if(v)v.style.cssText='font-family:var(--font-serif);font-size:24px;color:#22863A;transition:all .5s';if(v)v.textContent='91%';const d=kpiCards[3].querySelector('.kpi-delta');if(d)d.textContent='↑ Nouveau record !'}
}

// NOTIF PANEL
function toggleNotifPanel(){
  const p=g('notifPanel');if(!p)return;
  const open=p.classList.contains('panel-open');
  p.classList.toggle('panel-open',!open);
  if(!open)refreshNotifPanel();
}
function refreshNotifPanel(){
  const list=g('notifList');if(!list)return;
  const all=[...AC.notifHistory,
    {message:'⚠ Devis #2026-047 — J+8 sans réponse',type:'warning',time:'09:12'},
    {message:'❌ Impayé Baptiste Morel — 2 350 € à J+47',type:'error',time:'08:45'},
    {message:'📊 Rapport IA Avril 2026 généré',type:'info',time:'08:00'},
    {message:'✅ Contrat Marie Castel signé eIDAS',type:'success',time:'Hier'},
    {message:'📄 PV de livraison généré — Florent Sauvage',type:'info',time:'Hier'},
  ];
  const C={success:'#22863A',warning:'#B95000',error:'#D92D20',info:'#2B7DC4'};
  list.innerHTML=all.slice(0,12).map(n=>`<div class="notif-item" onclick="g('notifPanel').classList.remove('panel-open')"><div class="notif-dot" style="background:${C[n.type]||C.info}"></div><div style="flex:1"><div class="notif-msg">${n.message}</div></div><div class="notif-time">${n.time}</div></div>`).join('');
}

// SEARCH
const SD=[
  {l:'Florent Sauvage',s:'Devis #2026-047 · 4 200 € · J+8 urgent',u:'pages/client.html',t:'client'},
  {l:'Baptiste Morel',s:'Impayé · 2 350 € · J+47 critique',u:'pages/client.html',t:'alerte'},
  {l:'Marie Castel',s:'Signé · 7 800 € · Tout est ok',u:'pages/client.html',t:'client'},
  {l:'Sophie Renard',s:'Devis envoyé · 1 800 € · J+5',u:'pages/client.html',t:'client'},
  {l:'Pierre Dubois',s:'Signé · 12 000 € · TPE',u:'pages/client.html',t:'client'},
  {l:'Rapport Avril 2026',s:'CA 38 400 € · 12 clients actifs',u:'pages/ia.html',t:'rapport'},
  {l:'Alertes IA',s:'4 alertes actives dont 2 critiques',u:'pages/ia.html',t:'alerte'},
  {l:'Devis #2026-047',s:'Florent Sauvage · 4 200 € · En attente',u:'pages/client.html',t:'doc'},
  {l:'Timer actif',s:'Mission FS · 12h30 ce mois',u:'pages/client.html',t:'timer'},
  {l:'Paramètres relances',s:'Seuil J+8 · Brevo · n8n',u:'#',t:'config'},
];
function openSearch(){
  openModal('searchModal');
  setTimeout(()=>{const i=g('searchInput');if(i){i.value='';i.focus();renderSR('')}},100);
}
function renderSR(q){
  const r=g('searchResults');if(!r)return;
  const TC={'client':'#EFF8FF|#175CD3','alerte':'#FEF3F2|#B42318','doc':'#ECFDF3|#027A48','rapport':'#F5F0FF|#6E40C9','timer':'#FFFAEB|#B45309','config':'#F8F7F5|#4A4844'};
  const item=h=>{const[bg,fg]=(TC[h.t]||'#F8F7F5|#4A4844').split('|');return`<a href="${h.u}" onclick="closeModal('searchModal')" style="display:flex;gap:12px;align-items:center;padding:11px 18px;text-decoration:none;border-bottom:1px solid #EFEFEC;transition:background .15s;cursor:pointer" onmouseenter="this.style.background='#FAF8F5'" onmouseleave="this.style.background=''"><div style="padding:2px 7px;border-radius:4px;font-size:10.5px;font-weight:600;background:${bg};color:${fg};flex-shrink:0;text-transform:uppercase;letter-spacing:.05em">${h.t}</div><div style="flex:1;min-width:0"><div style="font-size:13.5px;font-weight:500;color:#1E1D1B">${h.l}</div><div style="font-size:12px;color:#8A8880;margin-top:1px">${h.s}</div></div><svg viewBox="0 0 24 24" fill="none" stroke="#C5C3BC" stroke-width="1.5" width="14" height="14"><polyline points="9 18 15 12 9 6"/></svg></a>`};
  if(!q){r.innerHTML='<div style="padding:6px 18px 8px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--slate-400)">Récents</div>'+SD.slice(0,5).map(item).join('');return}
  const hits=SD.filter(d=>d.l.toLowerCase().includes(q)||d.s.toLowerCase().includes(q));
  r.innerHTML=hits.length?hits.map(item).join(''):`<div style="padding:32px;text-align:center;color:#8A8880;font-size:13px">Aucun résultat pour « ${q} »</div>`;
}
document.addEventListener('input',e=>{if(e.target.id==='searchInput')renderSR(e.target.value.toLowerCase().trim())});

// AI CHAT
const AIR={
  default:["D'après votre dossier, je recommande d'envoyer la relance J+8 à Florent Sauvage aujourd'hui. Le taux de réponse est de 73% pour ce profil.","Baptiste Morel présente un score de 9.1/10. Une MED est recommandée sous 48h. Je peux préparer le document.","Votre CA d'avril est en hausse de +12%. Ce rythme projeté donne 460 000 € annuels — au-dessus de votre objectif.","Je détecte 2 clients sans contrat signé. Voulez-vous que je génère des rappels automatiques ?","Vos clients freelances paient en 18 jours en moyenne. Les artisans en 32 jours. Les TPE sont les plus rapides (14j)."],
  relance:"Pour Florent Sauvage, un ton amiable mais direct est recommandé. Il a ouvert votre email à 9h34, ce qui indique un intérêt actif. Je peux rédiger une relance mettant en avant la valeur livrée.",
  impaye:"Baptiste Morel est à J+47 — au-delà du seuil légal (art. 1344 CC). Je peux préparer la MED. Les tribunaux de commerce traitent ces dossiers en 3 à 6 semaines en moyenne.",
  devis:"Votre taux de signature est de 87% ce mois, contre 62% en moyenne sectorielle. Les devis envoyés le mardi matin ont le meilleur taux (94%).",
  timer:"Vous avez 12h30 sur le dossier Florent Sauvage ce mois. À votre TJM de 450 €/j, cela représente ~703 € non encore facturés.",
};

function toggleAIChat(){
  AC.aiChat.open=!AC.aiChat.open;
  const p=g('aiChatPanel');if(!p)return;
  p.style.transform=AC.aiChat.open?'translateY(0)':'translateY(calc(100% + 20px))';
  if(AC.aiChat.open&&AC.aiChat.messages.length===0){
    setTimeout(()=>addAIMsg("Bonjour Laure 👋 J'ai analysé vos dossiers ce matin — <strong>2 actions urgentes</strong> sont nécessaires.<br><br>Tapez une question ou cliquez sur une suggestion ci-dessous.",'ai'),350);
  }
  g('aiInput')?.focus();
}
function addAIMsg(text,role){
  AC.aiChat.messages.push({text,role});renderChat();
}
function renderChat(){
  const box=g('chatMessages');if(!box)return;
  box.innerHTML=AC.aiChat.messages.map(m=>`<div style="display:flex;gap:8px;margin-bottom:12px;${m.role==='user'?'flex-direction:row-reverse':''}"><div style="width:28px;height:28px;background:${m.role==='ai'?'var(--slate-900)':'var(--coral)'};border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:10px;color:${m.role==='ai'?'var(--coral-mid)':'white'};font-weight:600">${m.role==='ai'?'IA':'LM'}</div><div style="max-width:82%;padding:10px 13px;border-radius:${m.role==='ai'?'4px 12px 12px 12px':'12px 4px 12px 12px'};background:${m.role==='ai'?'var(--slate-50)':'var(--coral)'};color:${m.role==='ai'?'var(--slate-900)':'white'};font-size:13px;line-height:1.55;border:${m.role==='ai'?'1.5px solid var(--slate-100)':'none'}">${m.text}</div></div>`).join('');
  box.scrollTop=box.scrollHeight;
}
function sendAIMessage(){
  const inp=g('aiInput');if(!inp||!inp.value.trim())return;
  const q=inp.value.trim();addAIMsg(q,'user');inp.value='';
  // typing indicator
  const box=g('chatMessages');
  const typing=document.createElement('div');
  typing.style.cssText='display:flex;gap:8px;margin-bottom:12px';
  typing.innerHTML=`<div style="width:28px;height:28px;background:var(--slate-900);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:10px;color:var(--coral-mid);font-weight:600">IA</div><div style="padding:10px 14px;background:var(--slate-50);border-radius:4px 12px 12px 12px;border:1.5px solid var(--slate-100);display:flex;gap:4px;align-items:center">${['0.2s','0.4s','0.6s'].map(d=>`<div style="width:6px;height:6px;background:var(--slate-300);border-radius:50%;animation:bounce 1s ${d} infinite"></div>`).join('')}</div>`;
  box?.appendChild(typing);if(box)box.scrollTop=box.scrollHeight;
  setTimeout(()=>{
    typing.remove();
    const ql=q.toLowerCase();
    let resp=AIR.default[Math.floor(Math.random()*AIR.default.length)];
    if(ql.includes('relance'))resp=AIR.relance;
    else if(ql.includes('impayé')||ql.includes('morel')||ql.includes('baptiste'))resp=AIR.impaye;
    else if(ql.includes('devis'))resp=AIR.devis;
    else if(ql.includes('timer')||ql.includes('temps')||ql.includes('heure'))resp=AIR.timer;
    addAIMsg(resp+'<div style="font-size:10.5px;color:rgba(0,0,0,0.3);margin-top:6px;font-style:italic">Analyse IA — Vérifiez avant d\'agir</div>','ai');
  },900+Math.random()*600);
}

// TIMER
window.startTimer=function(){
  if(AC.timer.running)return;AC.timer.running=true;
  g('playBtn')?.setAttribute('style','display:none');g('stopBtn')?.setAttribute('style','display:flex');
  const s=g('timerStatus');if(s)s.textContent='⏱ Timer en cours…';
  AC.timer.interval=setInterval(()=>{AC.timer.seconds++;const d=g('timerDisplay');if(d)d.textContent=fmtTime(AC.timer.seconds);const mt=g('miniTimer');if(mt)mt.textContent=fmtTime(AC.timer.seconds)},1000);
  showToast('Timer démarré — '+AC.timer.taskLabel,'success');
  logAct('Timer démarré — '+AC.timer.taskLabel);
};
window.stopTimer=function(){
  if(!AC.timer.running)return;clearInterval(AC.timer.interval);AC.timer.running=false;
  g('playBtn')?.setAttribute('style','display:flex');g('stopBtn')?.setAttribute('style','display:none');
  const s=g('timerStatus');if(s)s.textContent=`Arrêté · ${fmtTime(AC.timer.seconds)} enregistré`;
  showToast(`${fmtTime(AC.timer.seconds)} enregistré ✓`,'success');
  logAct('Timer arrêté — '+fmtTime(AC.timer.seconds)+' enregistrés');
};

// ACTIVITY
function logAct(msg){AC.activityLog.unshift({time:new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),msg});refreshActivityFeed()}
function refreshActivityFeed(){
  const feed=g('activityFeed');if(!feed)return;
  feed.innerHTML=AC.activityLog.slice(0,10).map(a=>`<div class="activity-item"><div class="activity-dot"></div><div class="activity-msg">${a.msg}</div><div class="activity-time">${a.time}</div></div>`).join('');
}

// BADGE
function updateBadge(){document.querySelectorAll('#notifBadge').forEach(b=>{b.textContent=AC.alerts>0?(AC.alerts>9?'9+':AC.alerts):'';b.style.display=AC.alerts>0?'flex':'none'})}

// ONBOARDING
const OB=[
  {sel:'.kpi-strip .kpi-card:first-child',text:'Vos KPIs en temps réel — cliquez pour filtrer la vue',pos:'bottom'},
  {sel:'.client-table tbody tr:first-child',text:'⚠️ Ce dossier est urgent — devis J+8 sans réponse',pos:'bottom'},
  {sel:'.ai-banner',text:'L\'IA surveille vos dossiers en continu et vous alerte automatiquement',pos:'top'},
];
function startOnboarding(){if(AC.onboarding.done)return;setTimeout(()=>showOBStep(0),2000)}
function showOBStep(i){
  if(i>=OB.length){endOB();return}
  const step=OB[i];const target=document.querySelector(step.sel);removeOBTip();
  if(!target){showOBStep(i+1);return}
  const rect=target.getBoundingClientRect();
  const tip=document.createElement('div');tip.id='obTip';
  tip.style.cssText=`position:fixed;z-index:5000;background:var(--slate-900);color:white;border-radius:10px;padding:13px 16px;max-width:260px;font-family:'DM Sans',sans-serif;font-size:13px;line-height:1.5;box-shadow:0 8px 24px rgba(0,0,0,.25);animation:fadeUp .3s ease`;
  tip.innerHTML=`<div style="font-size:10.5px;color:var(--coral-mid);font-weight:600;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px">Astuce ${i+1}/${OB.length}</div>${step.text}<div style="display:flex;gap:8px;margin-top:10px"><button onclick="showOBStep(${i+1})" style="background:var(--coral);color:white;border:none;border-radius:5px;padding:5px 12px;font-family:'DM Sans',sans-serif;font-size:12px;cursor:pointer">${i===OB.length-1?'Terminer':'Suivant →'}</button><button onclick="endOB()" style="background:rgba(255,255,255,.1);color:rgba(255,255,255,.7);border:none;border-radius:5px;padding:5px 12px;font-family:'DM Sans',sans-serif;font-size:12px;cursor:pointer">Ignorer</button></div>`;
  let top=rect.bottom+window.scrollY+10;
  let left=Math.max(8,Math.min(rect.left+rect.width/2-130,window.innerWidth-270));
  if(step.pos==='top')top=rect.top+window.scrollY-130;
  tip.style.top=top+'px';tip.style.left=left+'px';
  target.style.cssText+='outline:2.5px solid #E85D3A;outline-offset:3px;border-radius:8px;transition:outline .3s';
  document.body.appendChild(tip);
}
function removeOBTip(){g('obTip')?.remove();document.querySelectorAll('[style*="outline:2.5px"]').forEach(e=>e.style.outline='')}
function endOB(){removeOBTip();AC.onboarding.done=true;localStorage.setItem('ac_ob','1');showToast('Tour terminé — ⌘K pour rechercher, ⌘/ pour l\'IA','info',4500)}
window.startOnboarding=startOnboarding;window.showOBStep=showOBStep;window.endOB=endOB;

// ALL GLOBALS
window.openModal=openModal;window.closeModal=closeModal;window.openSearch=openSearch;window.showToast=showToast;
window.toggleAIChat=toggleAIChat;window.sendAIMessage=sendAIMessage;window.toggleNotifPanel=toggleNotifPanel;
window.markAllRead=function(){document.querySelectorAll('.alert-item').forEach((item,i)=>setTimeout(()=>{item.style.cssText+='opacity:0;transform:translateX(12px);transition:all .3s';setTimeout(()=>item.remove(),300)},i*80));AC.alerts=0;updateBadge();setTimeout(()=>showToast('Toutes les alertes lues ✓','success'),500)};
window.dismissAlert=function(btn,msg){const item=btn.closest('.alert-item');if(item){item.style.cssText+='opacity:0;transform:translateX(12px);transition:all .3s';setTimeout(()=>item.remove(),300)}AC.alerts=Math.max(0,AC.alerts-1);updateBadge();if(msg)showToast(msg,'info')};
window.cycleStatus=function(el){const ss=[{c:'badge-info',t:'En cours'},{c:'badge-warning',t:'Devis envoyé'},{c:'badge-success',t:'Signé'},{c:'badge-danger',t:'Impayé'}];const cur=ss.findIndex(s=>el.classList.contains(s.c));const next=ss[(cur+1)%ss.length];ss.forEach(s=>el.classList.remove(s.c));el.classList.add(next.c);el.textContent=next.t;showToast(`Statut → ${next.t}`,'info');logAct('Statut mis à jour : '+next.t)};
window.exportCSV=function(){const csv=`Nom,Email,Statut,Montant HT,Score IA\nFlorent Sauvage,florent.sauvage@gmail.com,Devis envoyé,4200,8.2\nMarie Castel,marie.castel@studio.fr,Signé,7800,2.8\nBaptiste Morel,b.morel@artisan.fr,Impayé,2350,9.1\nAurélie Laurent,aurelie@graphiste.fr,En cours,5600,5.4\nPierre Dubois,p.dubois@conseil.fr,Signé,12000,1.5\nSophie Renard,s.renard@coaching.fr,Devis envoyé,1800,6.1\nThomas Mercier,t.mercier@plomberie.fr,Signé,3200,2.2`;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download='adminconnect_clients_avril2026.csv';a.click();showToast('Export CSV téléchargé ✓','success');logAct('Export CSV — 7 clients')};
window.submitNewClient=function(){const nom=g('nc_nom')?.value?.trim();const email=g('nc_email')?.value?.trim();const type=g('nc_type')?.value;if(!nom||!email){showToast('Nom et email obligatoires','warning');return}closeModal('newClientModal');showToast(`Client « ${nom} » créé ✓`,'success');logAct('Nouveau client : '+nom);const tbody=document.querySelector('.client-table tbody');if(!tbody)return;const ini=nom.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();const cols=[['#F0FBF4','#22863A'],['#EFF8FF','#175CD3'],['#F5F0FF','#6E40C9'],['#FDF6EC','#B95000']];const[bg,fg]=cols[Math.floor(Math.random()*cols.length)];const tr=document.createElement('tr');tr.style.cssText='cursor:pointer;animation:fadeUp .4s ease';tr.onclick=()=>window.location='pages/client.html';tr.innerHTML=`<td><div class="client-cell"><div class="client-avatar" style="background:${bg};color:${fg}">${ini}</div><div><div class="client-name">${nom}</div><div class="client-meta">${type||'Freelance'} · ${email}</div></div></div></td><td><span class="badge badge-info" onclick="event.stopPropagation();cycleStatus(this)" style="cursor:pointer">En cours</span></td><td class="amount">—</td><td class="date-cell"><span style="color:var(--coral);font-weight:500">À l'instant</span></td><td><div class="score-cell"><div class="score-bar"><div class="score-fill score-ok" style="width:10%"></div></div><span class="score-num ok">1.0</span></div></td><td><span class="relance-badge relance-none">Aucune</span></td><td class="actions-cell" onclick="event.stopPropagation()"><button class="icon-btn" onclick="showToast('Email envoyé à ${nom} ✓','success')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></button><button class="icon-btn" onclick="window.location='pages/client.html'">→</button></td>`;tbody.prepend(tr);g('nc_nom').value='';g('nc_email').value=''};
window.sendRelance=function(){closeModal('relanceModal');showToast('Relance envoyée via Brevo ✓','success');setTimeout(()=>showToast('Email livré · Tracking actif · Log RGPD conservé','info',4000),1200);const btn=g('relanceBtnMain');if(btn){btn.innerHTML='✓ Relance envoyée';btn.disabled=true;btn.style.opacity='.6'}const dot=document.querySelector('.relance-dot.current');if(dot){dot.classList.remove('current');dot.classList.add('done');dot.textContent='✓'}const next=document.querySelector('.relance-dot.future');if(next){next.classList.remove('future');next.classList.add('current');next.textContent='!'}AC.alerts=Math.max(0,AC.alerts-1);updateBadge();logAct('Relance envoyée — Florent Sauvage')};
window.sendPV=function(){closeModal('pvModal');showToast('PV envoyé via Yousign ✓','success');setTimeout(()=>showToast('Signature eIDAS en attente — notification automatique','info',5000),1500);const badge=document.querySelector('.doc-item:last-child .badge');if(badge){badge.className='badge badge-warning';badge.textContent='En signature'}logAct('PV envoyé — Florent Sauvage · Yousign')};
window.sendMED=function(){closeModal('medModal');showToast('MED préparée — validation juriste requise','warning',5000);logAct('MED préparée — Baptiste Morel · 2 350 €')};
window.saveNote=function(){const text=g('noteText')?.value?.trim();if(!text){showToast('La note est vide','warning');return}closeModal('noteModal');showToast('Note enregistrée ✓','success');logAct('Note interne mise à jour')};
window.generateReport=function(){const btn=g('reportBtn');if(btn){btn.textContent='⏳ Génération…';btn.disabled=true}setTimeout(()=>{if(btn){btn.textContent='Générer un nouveau rapport';btn.disabled=false}showToast('Rapport Avril 2026 généré et envoyé ✓','success');logAct('Rapport IA Avril 2026 généré')},2200)};
window.updateRelancePreview=function(type){const p=g('relancePreview');if(!p)return;const t={amiable:`Bonjour Florent,<br><br>Je reviens vers vous concernant le devis #2026-047 (4 200 € HT). Pourriez-vous me faire part de votre retour ?<br><br><em>Laure Macor</em>`,rappel:`Bonjour Florent,<br><br>Malgré mon précédent message, ce devis reste sans réponse. Sans retour avant le <strong>10 mai</strong>, d'autres démarches seront envisagées.<br><br><em>Laure Macor</em>`,premed:`Madame, Monsieur,<br><br>Vous êtes mis en demeure de répondre au devis #2026-047 (<strong>4 200 € HT</strong>) sous 8 jours ouvrés.<br><br><em>Art. 1344 CC — Laure Macor</em>`};p.innerHTML=t[type]||t.amiable};

// INIT
document.addEventListener('DOMContentLoaded',()=>{
  updateBadge();refreshActivityFeed();

  // Score circles
  document.querySelectorAll('.score-circle[data-score]').forEach(circle=>{
    const score=parseFloat(circle.dataset.score);const pct=Math.round((score/10)*100);
    const color=score>7?'#D92D20':score>5?'#B95000':'#22863A';
    circle.style.background=`conic-gradient(${color} ${pct}%, var(--slate-100) ${pct}%)`;
    const num=circle.querySelector('.score-circle-num');if(num)num.style.color=color;
  });

  // Animate score bars
  document.querySelectorAll('.score-fill').forEach(bar=>{
    const w=bar.style.width;bar.style.width='0';
    setTimeout(()=>{bar.style.transition='width .8s cubic-bezier(.22,1,.36,1)';bar.style.width=w},400);
  });

  // Animate chart bars
  document.querySelectorAll('.chart-bar').forEach((bar,i)=>{
    const h=bar.style.height;bar.style.height='0';
    setTimeout(()=>{bar.style.transition='height .5s ease';bar.style.height=h},100+i*55);
  });

  // Search
  const si=document.querySelector('.search-box input');
  if(si){si.addEventListener('focus',()=>openSearch());si.addEventListener('mousedown',e=>{e.preventDefault();openSearch()})}

  // Filters
  document.querySelectorAll('.filter-tab').forEach(tab=>{
    tab.addEventListener('click',function(){this.closest('.filter-tabs').querySelectorAll('.filter-tab').forEach(t=>t.classList.remove('active'));this.classList.add('active')})
  });

  // Live events
  startLiveEvents();

  // Onboarding
  startOnboarding();

  // AI chat enter
  const aiInp=g('aiInput');
  if(aiInp)aiInp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendAIMessage()}});

  // Init activity log
  ['Connexion — Laure Macor · AdminConnect','Rapport IA Avril 2026 chargé','4 alertes détectées au démarrage'].forEach((msg,i)=>{
    AC.activityLog.push({time:['09:00','09:01','09:02'][i],msg});
  });
  refreshActivityFeed();
  refreshNotifPanel();
});
